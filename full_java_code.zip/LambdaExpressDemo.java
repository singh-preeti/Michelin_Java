
@FunctionalInterface
interface LambdaDemo{
	void display();
}
public class LambdaExpressDemo {
	public static void main(String[] args) {
		LambdaDemo demo ;
		demo = new LambdaDemo() {

			@Override
			public void display() {
				System.out.println("Displaying.....");
				
			}
			
		};
		demo.display();
	}

}
