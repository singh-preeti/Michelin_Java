package com.collection;

import java.util.LinkedList;
import java.util.Queue;

public class QueueDemo {
	public static void main(String[] args) {
		Queue<Integer> values = new LinkedList<>();
		values.add(1);
        values.add(2);
        values.add(3);
        
        System.out.println(values);
	}
	
	

}
