package com.exception;

import java.io.FileNotFoundException;

public class ExceptionDemo {
	public static void main(String[] args) throws ArithmeticException {
		//try {
		System.out.println("10");
		System.out.println("20");
		System.out.println("30");
		System.out.println(40/0);
		System.out.println("50");
		System.out.println("60");
		//}
//		catch(ArithmeticException obj)
//		{
//			//System.out.println(obj);
//			System.exit(0);
//		}
//		catch(Exception ex)
//		{
//			System.out.println(ex);
//		}
//		finally {
//			//always get executed
//			System.out.println("Releaseing the resources!");
//		}
	}

}
