
public class NestedInnerClass1
{
    class Inner
    {
        public void show ()
        {
            System.out.println ("In a nested class method");
        }
    }
    
    public static void main (String[]args)
    {
        NestedInnerClass1.Inner in = new NestedInnerClass1 ().new Inner ();
        in.show ();
    }
}