

interface A
{
  void display();
}
interface B
{
 void openHotstar();	
}
public class NestedInnerClass
{
    
    
    public static void main (String[]args)
    {
        //NestedInnerClass.Inner in = new NestedInnerClass ().new Inner ();
        //in.show ();
 	A obj ;
       obj = new A(){

		@Override
		public void display() {
			System.out.println("Displaying..");
			
		}
         
      
    };
     B obj1;
     obj1 = new B() {

		@Override
		public void openHotstar() {
			System.out.println("Can access the hotstar with login details!");
			
		}
    	 
     };
     obj1.openHotstar();
     obj.display();
    }
}