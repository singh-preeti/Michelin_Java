package com.inheritance;
abstract class Parent
{
	 abstract public int add(int a,int b);
	 
}
class Child extends Parent
{
	@Override
	public int add(int a,int b)
	 {
		 int c= a+b;
		 System.out.println(c);
		 return c;
	 }

	
	
}
public class OverRideDemo {

}
