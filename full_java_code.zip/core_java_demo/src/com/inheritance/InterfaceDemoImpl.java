package com.inheritance;

public class InterfaceDemoImpl implements InterfaceDemo {
 
	public void show()
	{
		System.out.println("Showing..");
	}
	
	public static void main(String[] args) {
		InterfaceDemo.add(10, 10);
		//InterfaceDemoImpl.add(10, 10);
		InterfaceDemo obj1 = new InterfaceDemoImpl();
		obj1.sub(10,5);
	}

}
