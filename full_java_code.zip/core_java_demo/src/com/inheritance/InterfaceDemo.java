package com.inheritance;

public  interface InterfaceDemo {
	static  int add(int a,int b) {{
		int c= a+b;
		System.out.println(c);
		return c;
	}}
	default int sub(int a,int b) {
		{
			int c= a-b;
			System.out.println(c);
			return c;
		}
	}
//	int div(int a,int b);
//	 int mult(int a,int b);
//	 int mod(int a,int b);
	

}
