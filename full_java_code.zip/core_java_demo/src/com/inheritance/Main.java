package com.inheritance;
class Parent1
{
  static void show()
  {
	  
	  System.out.println("Showing the images..");
  }
}
interface  Parent2
{//abstract ( the method which is unimplemented/method without body)
 public void access();
 
}
public class Main extends Parent1  implements  Parent2 {
	public static void main(String[] args) {
		show();
		Main obj = new Main();
		obj.access();
	}

	@Override
	public void access() {
		{
			 System.out.println("able to login and access the account!");
		 }
		
	}

}
