package com.inheritance;
class GrandParent
{
}
class Parent1 extends GrandParent{
	
}
class Parent2 extends GrandParent
{
}
class Child1 extends Parent1{
	
}
class Child2 extends Parent1{}

class Child3 extends Parent2
{
	}
class Child4 extends Parent2{}
 class Child11 extends Child1{}
public class HirarchyDemo {

}
