package com.polymorphism;
class Student
{
	 String student_name = "Revati";
	 String stud_name = "Meghana";
	 int stud_id;
	 //poly -> many morphism -> forms
	 //method overloading (same name of methods with different parameter list
	 public void showName(String name) {
		 System.out.println("Student Name is" +student_name);
	 }
	 public void showName() {
		 System.out.println("Student Name is" +stud_name);
	 }
	 public int add(int a,int b)
	 {
		 int c= a+b;
		 System.out.println(c);
		 return c;
	 }
	 public float add(float a,int b)
	 {
		  float c= a+b;
		 System.out.println(c);
		 return c;
	 }
	 
	 
}
	 
public class OverloadingDemo {
 public static void main(String[] args) {
	 Student student = new Student();
	 student.showName();
}
}
