package com.operatorinjava;
public class AssignmentOperator
{
    public static void main (String[]args)
    {
        int a = 10;
        int b = 20;
        int c ;
             
//        System.out.println (c = a); // Output =10
//        System.out.println (b += a); // Output=30
//        System.out.println (a -= b); // Output=20
//        System.out.println (b += a);
        System.out.println (b =+ a);
//        System.out.println (b *= a); // Output=200
//        System.out.println (b /= a); // Output=2
//        System.out.println (b %= a); // Output=0
//        System.out.println (b ^= a); // Output=0
    }
}