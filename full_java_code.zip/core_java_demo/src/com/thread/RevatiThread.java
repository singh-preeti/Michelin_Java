package com.thread;

 class RevatiThreads implements Runnable{
	public void run() {
		System.out.println("Thread" +Thread.currentThread().getId() + " is running!");
	}

}
 public class RevatiThread {
	
	public static void main(String[] args) {
		int number = 10;
		for(int i = 0; i < number; i++) {
			
			RevatiThreads revati = new RevatiThreads();
			Thread t1 = new Thread(revati);
			t1.start();
			
			
		}
	}
}