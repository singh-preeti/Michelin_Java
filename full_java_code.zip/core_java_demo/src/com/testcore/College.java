package com.testcore;

public class College {

    public void createEvents()
        {
            System.out.println("Cultural Events are managed by the college:");
        }

    private void Library()
        {
            System.out.println("The library is there for reading");
        }

    }

    class Student1  extends College
    {
        public void dailyVehicle()
        {
            System.out.println("Daily vehicle is managed by student");
        }
        public static void main(String[] args) {
            Student1 stud = new Student1();
            College cl = new College();
            cl.createEvents();
           // Method Library = cl.College.getDeclareMethod("")
            stud.createEvents();
            stud.dailyVehicle();
        }
    }