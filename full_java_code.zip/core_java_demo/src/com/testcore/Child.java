package com.testcore;
//public,private,protected,default
 class GrandParent{
	
	 int add(int a,int b) {
		int c = a+b;
		System.out.println("Addition of two numbers are"+c);
		return c;
	}
}
class Parent  extends GrandParent
{
  public int mult(int a,int b) {
	  int c = a*b;
	  System.out.println("Product of two numbers are" +c);
	  return c;
  }	
}
public class Child extends Parent {
	
	 public int sub(int a,int b) {
		  int c = a-b;
		  System.out.println("Subtraction of two numbers are" +c);
		  return c;
	  }	
	 public int div(int a,int b) {
		  int c = a/b;
		  System.out.println("Division of two numbers are" +c);
		  return c;
	  }	
	 public static void main(String[] args) {
		Child ch = new Child();
		ch.sub(10, 5);
		ch.div(20, 10);
		ch.mult(20, 10);
		ch.add(10, 30);
	}
}
