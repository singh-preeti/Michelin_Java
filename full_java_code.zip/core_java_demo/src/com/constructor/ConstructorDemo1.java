package com.constructor;

public class ConstructorDemo1 {
	int id;
	String name;
	
	ConstructorDemo1(int i,String n)
	{
		this.id=i;
		this.name=n;
	}
	void dispay() {
		System.out.println(id+ " " +name);;
	}
	public static void main(String[] args) {
		ConstructorDemo1 con = new ConstructorDemo1(101,"Revati");
		ConstructorDemo1 con1 = new ConstructorDemo1(102,"Amar");
		con.dispay();
		con1.dispay();
	}
}
