package com.constructor;

public class ConstructorDemo {
	int id;
	String name;
	ConstructorDemo(){
		System.out.println("Created default constructor!");
	}
	void dispay() {
		System.out.println(id+ " " +name);;
	}
	public static void main(String[] args) {
		ConstructorDemo con = new ConstructorDemo();
		con.dispay();
	}

}
