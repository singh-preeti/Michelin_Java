package com.basic;

public class ForEachDemo {
	public static void main(String[] args) {
		int a[] = {22,55,88,99,11};
		String arr[] = {"preety","meghana","malhar"};
		
		for(int i=0;i<arr.length;i++)
		{
			System.out.println(arr[i]);
		}
		for(String i:arr) {
			System.out.println(i);
		}
		
		
	}

}
