package com.basic;

public interface ShowProduct {
	 void showProduct();
}
