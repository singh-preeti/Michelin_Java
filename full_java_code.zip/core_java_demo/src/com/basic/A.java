package com.basic;

public interface A {
  void showProduct();
 void  showPrice();
 void  showCustomerDetails();
}
