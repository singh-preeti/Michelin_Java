package com.basic;

public class ConditionDemo {
	public static void main(String[] args) {
		int age = 20;
		int number = 10;
		if(number%2==0)
		{
			System.out.println("Yes");
		}
		else
		{
			System.out.println("NO");
		}
	}

}
//int number =15;
//String result = (number%2==0)?"Even":"odd";
//syso(result);
