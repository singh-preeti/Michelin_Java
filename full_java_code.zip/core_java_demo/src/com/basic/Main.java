package com.basic;
 class Green {
	   public void getColor() {
		   //calculateEmi(){}
	      System.out.println("Green");
	   }
	}

	 class Blue extends Green {
	   public void getColor() {
	      //super.getColor();
	      System.out.println("Blue");
	   }
	}
public class Main {
	public static void main(String[] args) {
		Green green = new Blue();
		green.getColor();
	}

}
