package com.basic;

public class ElseIfDemo {
	public static void main(String[] args) {
		int percentage = 60;
		
		if(percentage<40)
		{
			System.out.println("Fail");
		}
		else if(percentage>=40 && percentage<60)
		{
			System.out.println("Second Div");
		}
		else if(percentage>=60 && percentage<75)
		{
			System.out.println("First Div");
		}
		else
		{
			System.out.println("Invalid");
		}
	}
}
