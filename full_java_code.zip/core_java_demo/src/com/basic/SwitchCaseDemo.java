package com.basic;

public class SwitchCaseDemo {
	
	public enum Days{Sun,Mon,Tue,Wed,Thu,Fri,Sat};
public static void main(String[] args) {
    Days[] dayNow = Days.values();
    for(Days Today:dayNow ) {
	
    	switch(Today) {
	case Sun: System.out.println("Sunday");
	
	break;
	
	case Mon: System.out.println("Monday");
	break;
	//default: System.out.println("case does not exists!");
	}
}
}
}

