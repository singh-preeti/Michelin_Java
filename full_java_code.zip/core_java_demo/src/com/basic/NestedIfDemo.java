package com.basic;

public class NestedIfDemo {
	public static void main(String[] args) {
		int age = 10;
		String country_name = "India";
		
		if(age>=18) {
			if(country_name=="india")
			{
				System.out.println("Person can vote");
			}
			else
			{
				System.out.println("NRI's can not vote");
			}
		}
		else
		{
			System.out.println("Can not vote");
		}
	}

}
