package com.basic;
class Product implements ShowProduct,ShowPrice
{
   void manufactureTyres() {
	   System.out.println("This is for manufacturing the product tyres!");
   }

@Override
public void showProduct() {
	// TODO Auto-generated method stub
	
}

@Override
public void showPrice() {
	// TODO Auto-generated method stub
	
}


}
public class LSPExample  extends Product {
	@Override
	void manufactureTyres() {
		super.manufactureTyres();
		 System.out.println("This is for showing the process of manufacturing");
	}
	void productManufacturing()
	{
		super.manufactureTyres();
	}

  public static void main(String[] args) {
	  Product prod = new LSPExample();
	  prod.manufactureTyres();
	  prod.manufactureTyres();
}
}
