package com.basic;

public interface ShowPrice {
	void  showPrice();
}
