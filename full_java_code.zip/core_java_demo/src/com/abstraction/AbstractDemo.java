package com.abstraction;
abstract class AbstractImpl
{
   abstract public void showEmi();
   public void showBalance() {
	   System.out.println("Your account balance is shown..");
   }
}
public class AbstractDemo extends AbstractImpl {

	@Override
	public void showEmi() {
		System.out.println("Showing the list of emi's");
		
	}
 public static void main(String[] args) {
	 AbstractDemo bank = new AbstractDemo();
	 bank.showBalance();
	 bank.showEmi();
}
}
