package com.java8features;
@FunctionalInterface
interface LambdaDemo{
	void display();
}
interface Demo{
	void openNetflix();
}
public class LambdaExpressDemo {
	public static void main(String[] args) {
		LambdaDemo demo ;
		demo = new LambdaDemo() {

			@Override
			public void display() {
				System.out.println("Displaying.....");
				
			}
			
		};
		
		
		Demo d ;
		d = new Demo() {

			@Override
			public void openNetflix() {
				System.out.println("Started...");
				
			}
			
		};
		d.openNetflix();
		demo.display();
	}

}
