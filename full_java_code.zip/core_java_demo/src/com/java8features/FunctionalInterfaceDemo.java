package com.java8features;
@FunctionalInterface
//(Single Abstract Method) SAM
interface Demo{
	void display();
	//void access();
	static  void openNetflix() {
		System.out.println("Starting the netflix..");
	}
	default void openHotstar()
	{
		System.out.println("Stating Hotstar!");
	}
}
class DemoImpl implements Demo{

	@Override
	public void display() {
		System.out.println("Showing data......");
		
	}
	
}
public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		DemoImpl demo = new DemoImpl();
		demo.display();
		demo.openHotstar();
		Demo.openNetflix();
		
}
}