package org.core.java;

 class College
{
	private void fdAccess()
	{
		System.out.println();
	}
    protected void operateLibary()
	 {
	    System.out.println("The library is there for reading and home issue");
	 }
	 void createEvents()
	 {
	    System.out.println("Cultural Events are managed by the college:");
	 }
	
}

class Student  extends College
{
	
    public void dailyVehicle()
    {
	  System.out.println("Daily vehicle is managed by student");
	}	
}
public class Main extends College {
public static void main(String[] args) {
	College college = new College();
	
	college.createEvents();
	college.operateLibary();
	
	Student student = new Student();
	student.createEvents();
	student.dailyVehicle();
	student.operateLibary();
	
}
}
