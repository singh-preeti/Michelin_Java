package org.core.java;

public class Calculator {
	
	//variable,data type
	//data members
	//member function/ methods
	//int a=10;
	
	//int b=20;
	//types of variable = global,local,parameterized
	String name="Preeti";
	public int add(int a,int b)
	{
		int c= a+b;
		System.out.println(c);
		return c;
	}
	public void display(String message) {
		System.out.println("Welcome to java class!");
	}
	public int sub(int a,int b)
	{
		 int c= b-a;
		System.out.println(c);
		return c;
	}
	public static void main(String[] args) {
		Calculator Meghna = new Calculator();
		Meghna.add(10,20);
		Meghna.sub(20,15);
		Meghna.display("hello");
	}
	
	
	
	

}
