package org.core.java;

class College1
{
    public void operateLibary()
	 {
	    System.out.println("The library is there for reading and home issue");
	 }
	 public void createEvents()
	 {
	    System.out.println("Cultural Events are managed by the college:");
	 }
	 public static void main(String[] args) {
		College1 stud = new College1();
		//stud.dailyVehicle();
		stud.createEvents();
	}
	
}

class Student1  extends College
{
	
    public void dailyVehicle()
    {
	  System.out.println("Daily vehicle is managed by student");
	}	
    public static void main(String[] args) {
		Student1 stud = new Student1();
		stud.createEvents();
		stud.operateLibary();
		stud.dailyVehicle();
	}
}

